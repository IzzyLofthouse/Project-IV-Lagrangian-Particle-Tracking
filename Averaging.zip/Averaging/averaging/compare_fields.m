%compares reconstructed Lagrangian velocity fields to actual Lagrangian
%velocity fields
load('Data_Av/uLM_averaging_sinc.mat') %or _th
load('/MATLAB Drive/SW_share/SW_share/Data/Fields/Lagrangian_tracer_values-50.mat','xx','yy','FuL_sinc','FvL_sinc')
%----number of tracers in reconstruction------
N= 100;

%------rename------
uLM = uLM_save_sinc(:,:,1,1);
vLM = vLM_save_sinc(:,:,1,1);

%----field difference------
du_sinc =  uLM - FuL_sinc(:,:,N);
dv_sinc = vLM - FvL_sinc(:,:,N);

%---plot difference in field (want = 0 everywhere)---
figure
subplot(1,2,1)
pcolor(xx,yy,du_sinc);
shading flat; colorbar
clim([-0.1,0.1]);
title("Lagrangian u field - reconstructed u field","FontSize", 16)

subplot(1,2,2)
pcolor(xx,yy,dv_sinc);
shading flat; colorbar
clim([-0.1,0.1]);
title("Lagrangian v field - reconstructed v field","FontSize", 16)

%---find relative error----
rel_err_u = norm(du_sinc(:)) / norm(uLM(:));
rel_err_v = norm(dv_sinc(:)) / norm(vLM(:));

disp(['Relative error u: ', num2str(rel_err_u)])
disp(['Relative error v: ', num2str(rel_err_v)])

%---plot reconstructed field next to actual field---
figure
subplot(1,2,1)
pcolor(xx,yy,FuL_sinc(:,:,N));

shading flat; colorbar
clim([-0.1,0.1]);
title('Reconstructed Lagrangian u field, 100 tracers',"FontSize", 16)

subplot(1,2,2)
pcolor(xx,yy,uLM);
shading flat; colorbar
clim([-0.1,0.1]);
title("Lagrangian u field","FontSize", 16)


figure
subplot(1,2,1)
pcolor(xx,yy,FvL_sinc(:,:,N));

shading flat; colorbar
clim([-0.1,0.1]);
title('Reconstructed Lagrangian v field, 100 tracers',"FontSize", 16)

subplot(1,2,2)
pcolor(xx,yy,vLM);

shading flat; colorbar
clim([-0.1,0.1]);
title("Lagrangian v field","FontSize", 16)

