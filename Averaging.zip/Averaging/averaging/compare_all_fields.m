%plots relative error between actual Lagrangian field and reconstructions 
%using N=1:1000 tracers. Compared to this with the original field
%------load actual Lagrangian velocity fields------
load('Data_Av/uLM_averaging_th.mat')
load('Data_Av/uLM_averaging_sinc.mat')

%------load saved fields for N=1:1000 tracers------
base = '/MATLAB Drive/SW_share/SW_share/Data/';

load([base 'Fields/Lagrangian_tracer_values-50.mat'])
load([base 'Original Field/og_field_recon_test.mat'])
load([base 'Tracer Diagnostics/tracer_diagnostics.mat'], 'u_field_save', 'v_field_save', 'save_interval')

%------Time vectors were filtered at------
time= 50;
take_vectors = time./save_interval;

%------rename------
uLM_th = uLM_save_th;
vLM_th = vLM_save_th; 

uLM_sinc = uLM_save_sinc;
vLM_sinc = vLM_save_sinc; 

%------norms of actual Lagrangian fields------
NuL_th = norm(uLM_th,'fro');
NvL_th = norm(vLM_th,'fro');

NuL_sinc = norm(uLM_save_sinc,'fro');
NvL_sinc = norm(vLM_sinc,'fro');

%------norm of shallow water field------
NuO = norm(u_field_save,'fro');
NvO = norm(v_field_save,'fro');

%------pre-allocate------
duL_th = zeros(256,256,1499);
dvL_th = zeros(256,256,1499);
duL_sinc = zeros(256,256,1499);
dvL_sinc = zeros(256,256,1499);
rel_err_u_L_th = zeros(256,1);
rel_err_v_L_th = zeros(256, 1);
rel_err_u_L_sinc = zeros(256,1);
rel_err_v_L_sinc = zeros(256, 1);

duO = zeros(256,256,1499);
dvO = zeros(256,256,1499);
rel_err_u_O = zeros(256,1);
rel_err_v_O = zeros(256, 1);

%------Find relative error for each reconstruction------
for i = 2:1000
    duL_th(:,:,i) = FuL_th(:,:,i) - uLM_th;
    dvL_th(:,:,i) = FvL_th(:,:,i) - vLM_th;
    rel_err_u_L_th(i) = norm(duL_th(:,:,i),'fro') / NuL_th;
    rel_err_v_L_th(i) = norm(dvL_th(:,:,i),'fro') / NvL_th;

    duO(:,:,i) = u_field_save - FuO(:,:,i);
    dvO(:,:,i) = v_field_save - FvO(:,:,i);
    rel_err_u_O(i) = norm(duO(:,:,i),'fro') / NuO;
    rel_err_v_O(i) = norm(dvO(:,:,i),'fro') / NvO;

    duL_sinc(:,:,i) = uLM_save_sinc - FuL_sinc(:,:,i);
    dvL_sinc(:,:,i) = vLM_sinc - FvL_sinc(:,:,i);
    rel_err_u_L_sinc(i) = norm(duL_sinc(:,:,i),'fro') / NuL_sinc;
    rel_err_v_L_sinc(i) = norm(dvL_sinc(:,:,i),'fro') / NvL_sinc; 
    disp("Done for tracer number " + i);
end

%------plot------
figure
subplot(1,2,1)
plot(rel_err_u_L_th,'r','LineWidth',1); hold on;
plot(rel_err_u_L_sinc, 'g','LineWidth',1);
plot(rel_err_u_O,'b','LineWidth',1); grid on;
title('Relative Error of reconstructed u fields');
xlabel('Number of tracers');
ylabel('Relative Error');
legend('Lagrangian u, top-hat', 'Lagrangian u, sinc','Original u reconstruction');
axis([0 1000 0 2])

subplot(1,2,2)
plot(rel_err_v_L_th, 'r','LineWidth',1); hold on; 
plot(rel_err_v_L_sinc, 'g','LineWidth',1);
plot(rel_err_v_O,'b','LineWidth',1); grid on;
xlabel('Number of tracers');
ylabel('Relative Error');
title('Relative Error of reconstructed v fields');
legend('Lagrangian v, top-hat', 'Lagrangian v, sinc','Original v reconstruction');
axis([0 1000 0 2])
hold off;