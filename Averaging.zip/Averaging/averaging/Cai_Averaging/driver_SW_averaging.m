function driver_SW_averaging(varargin)

addpath('/MATLAB Drive/SW_share/SW_share/./rfftCai/')
addpath('/MATLAB Drive/SW_share/SW_share/./cmocean/')

addpath('./filters')

set(0, 'DefaultLineLineWidth', 1.5);
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultAxesTickLabelInterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');

set(groot, "defaultFigureWindowStyle", "normal")

% variables with a k after them denotes the spectral version of that
% variable, e.g. uk = rfft2(u)

%% general setup

load(varargin{1});
% varargin{1} is filename containing initial condition and other
% parameters

% setup based on input parameters
t = 0:dt:t_end; % fast timescale times

save_count = 1;
save_count_M = 1;

% x-wavenumbers are for rfft
% y-wavenumbers are as for normal fft (so fftshift can be used here)
num_k = num_x/2+1;
num_l = num_y;
kk = 0:num_x/2;
ll = [0:num_y/2-1, -num_y/2:-1];
[k,l] = meshgrid(kk,ll);
% % mask for dealiasing
mask = true(num_y*3/2,num_x*3/4+1);
mask(num_y/2+1:num_y,:) = false;    % make false the l outside of range
mask(:,num_x/2+2:num_x*3/4+1) = false;    % same for k
%indices of nonzero mask values
mask_inds_k = 1:num_x/2+1;
mask_inds_l = [1:num_y/2, num_y+1:num_y*3/2];

ik = 1i*k;
il = 1i*l;
K2 = k.^2 + l.^2;

omega = sqrt(f^2 + g*H*K2);

t_save = 0:save_interval:t_end;
% indices of t_save within t
[~,t_save_inds] = ismembertol(t_save,t);
% redefine t_save using these indices
t_save = t(t_save_inds);
num_t_save = length(t_save);


% store data for plotting later. fourth dimension is slow save times
Uk_save = zeros(num_l,num_k,3,num_t_save);

% Uk_save stores Uk at the slow times
Uk_save(:,:,:,1) = Uk;

% calculate matrix exponentials of -Adt/2 in advance, where A is linear 
% wave operator matrix in spectral space (A_1 in overleaf document)
% here waveOperator_halfdt_ is an array where the first 2 dimensions
% correspond to wavenumbers in spectral space, the 3rd and 4th are the
% matrix rows and columns, and 5th dimension is for unique values of dt
waveOperator_halfdt_ = SW_wave_exp_nWdt(f,g,H,k,l,omega,K2,num_k,num_l,dt/2);


%% averaging setup
% define filters here
% will use vectors of times, G and G_int and interpolate, instead of
% using function handles
t_G = 0:dt:T/2;     %%was T/2 
% make sure T is inside t_G and extend to -T/2
t_G = [-flip(t_G),t_G(2:end)];
if strcmp(kernel,'tophat')
    % top hat
    G = tophat(t_G,T_tophat);
elseif strcmp(kernel,'Gaussian')
    % Gaussian
    G = Gaussian(t_G,T,sigma_G);
elseif strcmp(kernel,'GaussianSinc')
    % Gaussian multiplied by sinc. Use sigma_G = 0 for 'ideal' low-pass
    % filter
    G = GaussianSinc(t_G,omega_c,sigma_G);
end
G_int = cumtrapz(t_G,G); % cumulative integral
G_int = G_int - 1/2*(G_int(end) - 1);

% indices of t_save_M within t
[~,t_save_M_inds] = ismembertol(t_save_M,t);

num_t_save_M = length(t_save_M);
% redefine t_save using these indices
t_save_M = t(t_save_M_inds);

num_t_M = round(T/dt) + 1;
n_window = round(T/dt) + 1;
t_M_ = zeros(num_t_M,num_t_save_M);
% for i = 1:num_t_save_M
%     [~,t_M_startInd] = ismembertol(t_save_M(i)-T/2,t);
%     [~,t_M_endInd] = ismembertol(t_save_M(i)+T/2,t);
% 
%     t_M_(:,i) = t(t_M_startInd:t_M_endInd);
% end

for i = 1:num_t_save_M
    [~, t_M_startInd] = min(abs(t - (t_save_M(i) - T/2)));
    [~, t_M_endInd]   = min(abs(t - (t_save_M(i) + T/2)));

    % Safety check
    n_steps = t_M_endInd - t_M_startInd + 1;
    if n_steps ~= num_t_M
        warning('t_save_M(%d): expected %d steps, got %d. Check T and dt.', ...
                i, num_t_M, n_steps);
    end

    t_M_(:,i) = t(t_M_startInd:t_M_endInd);
end
% initialise strategy 3 variables
% mapping midpoint actual position to endpoint (in time) actual position
xiEnd_save = zeros(num_y,num_x,2,num_t_save_M);
% mapping midpoint actual position to mean position
xiMean_save = zeros(num_y,num_x,2,num_t_save_M);

% Lagrangian mean velocity at actual position
uvLM_phi_save = zeros(num_y,num_x,2,num_t_save_M);
% % Lagrangian mean vorticity at actual position
% zetaLM_phi_save = zeros(num_y,num_x,1,num_t_save_M);

% initialise Eulerian means
uvEM_save = zeros(num_y,num_x,2,num_t_save_M);
% zetaEM_save = zeros(num_y,num_x,1,num_t_save_M);

% initialise departure and arrival time indices of t_M
i_a_ = 2*ones(1,num_t_save_M);


%% initial plot and time evolution
zetak = ik.*Uk(:,:,2) - il.*Uk(:,:,1);

figure
% clim_init = [-max(abs(irfft2(Uk(:,:,2))),[],'all'),max(abs(irfft2(Uk(:,:,2))),[],'all')];
% illustrate(x,y,irfft2(Uk(:,:,2)));
clim_init = [-max(abs(irfft2(zetak)),[],'all'),max(abs(irfft2(zetak)),[],'all')];
illustrate(x,y,irfft2(zetak));
clim(clim_init);
clim([-1,1]);
title("\(t=\) " + 0);
pause(0.01);
drawnow;

tic

% loop over values of t0. integrate from t0 to t0+dt
for t_ind = 1:length(t)-1
    % find t_d and t_a
    t_d = t(t_ind);
    t_a = t(t_ind + 1);
    
    % velocities at start of timestep
    u_d = irfft2(Uk(:,:,1));
    v_d = irfft2(Uk(:,:,2));

    % advance shallow water ===============================================
    if MSW
        Uk = advance_MSW(Uk,dt,ik,il,waveOperator_halfdt_,mask_inds_k,mask_inds_l,nu,K2,g,H);
    else
        Uk = advance_SW(Uk,dt,ik,il,waveOperator_halfdt_,mask_inds_k,mask_inds_l,nu,K2,H);
    end
    zetak = ik.*Uk(:,:,2) - il.*Uk(:,:,1);

    % velocities at end of timestep
    u_a = irfft2(Uk(:,:,1));
    v_a = irfft2(Uk(:,:,2));

    % ---------------------------------------------------------------------
    % M calculations
    % loop over slow save times of interest
    % assume M times are equal to governing equation times
    for i_save_M = 1:num_t_save_M
        t_M_a = t_M_(i_a_(1,i_save_M),i_save_M);
        t_M_d = t_M_(i_a_(1,i_save_M)-1,i_save_M);
        
        % if arrival times coincide
        if t_a == t_M_a
        
            % get value of M variables at departure time
            xiEnd_d = xiEnd_save(:,:,:,i_save_M);
            xiMean_d = xiMean_save(:,:,:,i_save_M);
            uvLM_phi_d = uvLM_phi_save(:,:,:,i_save_M);
            % zetaLM_phi_d = zetaLM_phi_save(:,:,:,i_save_M);

            % get G at departure and arrival times
            [~,ind_t_G_d] = ismembertol(t_M_d - t_save_M(i_save_M),t_G);
            G_d = G(ind_t_G_d);
            G_int_d = G_int(ind_t_G_d);
    
            [~,ind_t_G_a] = ismembertol(t_M_a - t_save_M(i_save_M),t_G);
            G_a = G(ind_t_G_a);
            G_int_a = G_int(ind_t_G_a);

            [xiEnd_a,xiMean_a,uvLM_phi_a] = advance_strat3_uv(u_a,v_a,u_d,v_d,...
                                    G_a,G_int_a,G_d,G_int_d,xiEnd_d,xiMean_d,uvLM_phi_d,...
                                    xx,yy,x,y,interp_methodx,dt,t_M_a,t_save_M(i_save_M));

            xiEnd_save(:,:,:,i_save_M) = xiEnd_a;
            xiMean_save(:,:,:,i_save_M) = xiMean_a;
            uvLM_phi_save(:,:,:,i_save_M) = uvLM_phi_a;

            % update Eulerian means
            uvEM_save(:,:,:,i_save_M) = uvEM_save(:,:,:,i_save_M) ...
                                + dt/2*cat(3,u_a*G_a + u_d*G_d,v_a*G_a + v_d*G_d);

            % update arrival index
            i_a_(1,i_save_M) = i_a_(1,i_save_M) + 1;
            % if arrival index is sufficiently large, set to 2
            if i_a_(1,i_save_M) > num_t_M
                i_a_(1,i_save_M) = 2;
            end
        end
        
    end


    % ---------------------------------------------------------------------
    % save data
    if ismember(t_ind+1,t_save_inds(2:end))     % already stored IC
        % illustrate(x,y,irfft2(Uk(:,:,2)));
        % illustrate(x,y,irfft2(zetak));
        % 
        % clim(clim_init);
        % clim([-1,1]);
        % title("\(t=\) " + t(t_ind+1));
        % pause(0.01);
        % drawnow;

        disp("Done up to t = " + t(t_ind+1));


        save_count = save_count + 1;
        Uk_save(:,:,:,save_count) = Uk;

    end
end

runtime = toc;
disp("Elapsed time = " + runtime);

clear -regexp a1 a2

if save_data
    %%
    save("output_averaging_sinc.mat");
end

%%
load('IC_av.mat')
load('output_averaging_sinc.mat')

uLM_save_sinc = zeros(num_y,num_x,1,num_t_save_M);
vLM_save_sinc = zeros(num_y,num_x,1,num_t_save_M);

for i = 1:num_t_save_M
    x_sample = mod(x + xiMean_save(:,:,1,i),2*pi);
    y_sample = mod(y + xiMean_save(:,:,2,i),2*pi);

    x_sample = reshape(x_sample,[numel(x_sample),1]);
    y_sample = reshape(y_sample,[numel(y_sample),1]);

    disp(size(x_sample))
    disp(size(y_sample))

    uLM_phi = uvLM_phi_save(:,:,1,i);
    uLM_phi = reshape(uLM_phi,[numel(uLM_phi),1]);

    vLM_phi = uvLM_phi_save(:,:,2,i);
    vLM_phi = reshape(vLM_phi,[numel(vLM_phi),1]);

    uLM_save_sinc(:,:,1,i) = remap2_periodic(x_sample,y_sample,uLM_phi,x,y); %was remap2_periodic
    vLM_save_sinc(:,:,1,i) = remap2_periodic(x_sample,y_sample,vLM_phi,x,y);  %was remap2_periodic
end

save('uLM_averaging_sinc.mat', 'uLM_save_sinc', 'vLM_save_sinc','num_t_save_M')