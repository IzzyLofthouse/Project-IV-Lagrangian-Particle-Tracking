% set initial condition

clear

save_data = true;
flow_type = 'wave+turb_av'; 

MSW = true;

num_x = 2^8;
num_y = num_x;

f = 1;  %was 2.5
g = 1; %was 10
H = 1;
nu = 1e-4;

U_scale = pi/15;

disp("Ro = " + U_scale/(f*2*pi/4))
disp("Fr = " + U_scale/sqrt(g*H))

xx = linspace(0,2*pi,num_x+1);
yy = linspace(0,2*pi,num_y+1);

dt = 1e-3; %was 1e-3
% final time
t_end = 100;

% times for saving figures
save_interval = 0.05; %was .05

xx = xx(1:end-1);
dx = xx(2) - xx(1);

yy = yy(1:end-1);
dy = yy(2) - yy(1);

[x,y] = meshgrid(xx,yy);

kk = 0:num_x/2;
ll = [0:num_y/2-1, -num_y/2:-1];
[k,l] = meshgrid(kk,ll);
% mask for dealiasing
mask = true(num_y*3/2,num_x*3/4+1);
mask(num_y/2+1:num_y,:) = false;    % make false the l outside of range
mask(:,num_x/2+2:num_x*3/4+1) = false;    % same for k
% indices of nonzero mask values
mask_inds_k = 1:num_x/2+1;
mask_inds_l = [1:num_y/2, num_y+1:num_y*3/2];

ik = 1i*k;
il = 1i*l;
K2 = k.^2 + l.^2;

%% set initial condition
U = zeros(num_y,num_x,3);   % dim 1 is y, dim 2 is x, dim 3 is u, v and h

% waves initial condition
a_w = 0.1; % amplitude of wave
k_w = 1;
l_w = 0;
omega_w = sqrt(f^2 + g*H*(k_w.^2+l_w.^2));


u_w = a_w .* (1/(k_w^2 + l_w^2) * ...
                ( omega_w*k_w*cos(k_w*x + l_w*y) - l_w*f*sin(k_w*x + l_w*y) ));
v_w = a_w .* (1/(k_w^2 + l_w^2) * ...
                ( omega_w*l_w*cos(k_w*x + l_w*y) + k_w*f*sin(k_w*x + l_w*y) ));
h_w = H*a_w .* cos(k_w*x + l_w*y);

%% flow type options
switch flow_type
    case 'rotating'
        U(:,:,1) = -y+pi;
        U(:,:,2) = x-pi;
        U(:,:,3) = 1;


    case 'wave+turb_av'
        load("turbHeight.mat")

        h_QGk = rfft2(h_QG);
        u_QGk = -g/f*il.*h_QGk;
        v_QGk = g/f*ik.*h_QGk;
        
        u_QG = irfft2(u_QGk);
        v_QG = irfft2(v_QGk);
        
        U_QG = max(sqrt(u_QG.^2 + v_QG.^2),[],"all");
        
        h_QG = h_QG*(U_scale/U_QG);
        u_QG = u_QG*(U_scale/U_QG);
        v_QG = v_QG*(U_scale/U_QG);
        % input the initial conditions into array U. this U changes on the fast
        % time scale
        U(:,:,1) = u_QG + u_w;
        U(:,:,2) = v_QG + v_w;
        U(:,:,3) = h_QG + h_w; % full height is H + U(:,:,3)
end

Uk = rfft2(U);

% averaging stuff
kernel = 'GaussianSinc';    % GaussianSinc or tophat or Gaussian
disp(kernel)
T =100;                  % prop want = t_end
omega_c = 1;              % cutoff frequency of sinc function
sigma_G = 0;              % standard deviation of Gaussian multiplying sinc function
T_tophat = 3*sqrt(2)*pi;

% set times to save Lagrangian mean fields. these are the slow times such
% that the averaging interval in inside [0,t_end].
t_save_M = 50; %was 10

interp_methodx = 'cubic';
interp_methodt = 'cubic';

save("IC_av.mat");

clear