T = 3;

omega_c = 40;
sigma_G = 8;

tt = linspace(-T/2,T/2,2^9+1);

fig = figure;
ax = axes(fig);
hold on

plot(tt,GaussianSinc(tt,omega_c,sigma_G))
plot(tt,GaussianSinc(tt,omega_c,sigma_G))


xlabel('\(t\)')
ylabel('\(G\)')


%%

om = linspace(-1000,1000,2^12+1);
dom = om(2)-om(1);


fig = figure;
ax = axes(fig);

hold on


plot(om,abs(om)<omega_c)
plot(om,1/erf(omega_c/(sqrt(2)*sigma_G)) * conv(abs(om)<omega_c,1/sqrt(2*pi)/(sigma_G)*exp(-om.^2/(2*(sigma_G)^2))*dom,'same'))

xlabel('\(\omega\)')
ylabel('\(\hat{G}\)')

ylim([0,1.25])

