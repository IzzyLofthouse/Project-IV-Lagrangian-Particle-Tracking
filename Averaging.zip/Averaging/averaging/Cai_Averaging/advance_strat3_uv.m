function [xiEnd_a,xiMean_a,uvLM_phi_a] = advance_strat3_uv(u_a,v_a,u_d,v_d,...
                                    G_a,G_int_a,G_d,G_int_d,xiEnd_d,xiMean_d,uvLM_phi_d,...
                                    xx,yy,x,y,interp_methodx,dt,t_M_a,t_save_M)

% get first and second components of remappings
xiEnd_1_d = xiEnd_d(:,:,1);
xiEnd_2_d = xiEnd_d(:,:,2);

xiMean_1_d = xiMean_d(:,:,1);
xiMean_2_d = xiMean_d(:,:,2);


% now advance fields
if t_M_a > t_save_M
    % first update xiEnd ---------------------------------------
    % get XiEnd_d evaluated at x, mod 2pi
    XiEnd_1_d = mod(x + xiEnd_1_d,2*pi);
    XiEnd_2_d = mod(y + xiEnd_2_d,2*pi);

    k1_xiEnd_1 = interp2_periodic(xx,yy,u_d,XiEnd_1_d,...
                                XiEnd_2_d,interp_methodx);
    k1_xiEnd_2 = interp2_periodic(xx,yy,v_d,XiEnd_1_d,...
                                XiEnd_2_d,interp_methodx);

    k2_xiEnd_1 = interp2_periodic(xx,yy,u_a,mod(XiEnd_1_d + dt*k1_xiEnd_1,2*pi),...
                                mod(XiEnd_2_d + dt*k1_xiEnd_2,2*pi),interp_methodx);
    k2_xiEnd_2 = interp2_periodic(xx,yy,v_a,mod(XiEnd_1_d + dt*k1_xiEnd_1,2*pi),...
                                mod(XiEnd_2_d + dt*k1_xiEnd_2,2*pi),interp_methodx);

    xiEnd_1_a = xiEnd_1_d + dt/2*(k1_xiEnd_1 + k2_xiEnd_1);
    xiEnd_2_a = xiEnd_2_d + dt/2*(k1_xiEnd_2 + k2_xiEnd_2);

    % write this updated xiEnd to the output variable
    xiEnd_a = cat(3,xiEnd_1_a,xiEnd_2_a);


    % then update xiMean ----------------------------------------
    k1_xiMean_1 = k1_xiEnd_1*(1 - G_int_d);
    k1_xiMean_2 = k1_xiEnd_2*(1 - G_int_d);

    k2_xiMean_1 = interp2_periodic(xx,yy,u_a,mod(x + xiEnd_1_a,2*pi),...
                                mod(y + xiEnd_2_a,2*pi),interp_methodx)...
                                *(1 - G_int_a);
    k2_xiMean_2 = interp2_periodic(xx,yy,v_a,mod(x + xiEnd_1_a,2*pi),...
                                mod(y + xiEnd_2_a,2*pi),interp_methodx)...
                                *(1 - G_int_a);

    xiMean_1_a = xiMean_1_d + dt/2*(k1_xiMean_1 + k2_xiMean_1);
    xiMean_2_a = xiMean_2_d + dt/2*(k1_xiMean_2 + k2_xiMean_2);

    xiMean_a = cat(3,xiMean_1_a,xiMean_2_a);


    % then update uvLM_phi -----------------------------------------
    k1_uvLM_phi_1 = k1_xiEnd_1*G_d;
    k1_uvLM_phi_2 = k1_xiEnd_2*G_d;

    k2_uvLM_phi_1 = interp2_periodic(xx,yy,u_a,mod(x + xiEnd_1_a,2*pi),...
                                mod(y + xiEnd_2_a,2*pi),interp_methodx)*G_a;
    k2_uvLM_phi_2 = interp2_periodic(xx,yy,v_a,mod(x + xiEnd_1_a,2*pi),...
                                mod(y + xiEnd_2_a,2*pi),interp_methodx)*G_a;

    uvLM_phi_a = uvLM_phi_d + dt/2*cat(3,k1_uvLM_phi_1 + k2_uvLM_phi_1, k1_uvLM_phi_2 + k2_uvLM_phi_2);

else
    % use second order Runge-Kutta backward in time to find
    % departure point
    k1_X_back = u_a;
    k1_Y_back = v_a;

    k2_X_back = interp2_periodic(xx,yy,u_d,mod(x - dt*k1_X_back,2*pi),...
                            mod(y - dt*k1_Y_back,2*pi),interp_methodx);
    k2_Y_back = interp2_periodic(xx,yy,v_d,mod(x - dt*k1_X_back,2*pi),...
                            mod(y - dt*k1_Y_back,2*pi),interp_methodx);

    X_d = mod(x - dt/2*(k1_X_back + k2_X_back),2*pi);
    Y_d = mod(y - dt/2*(k1_Y_back + k2_Y_back),2*pi);

    % xiEnd isn't modified here
    xiEnd_a = xiEnd_d;

    % then update xiMean ----------------------------------------
    k1_xiMean_1 = interp2_periodic(xx,yy,u_d,X_d,Y_d,interp_methodx)*( - G_int_d);
    k1_xiMean_2 = interp2_periodic(xx,yy,v_d,X_d,Y_d,interp_methodx)*( - G_int_d);

    k2_xiMean_1 = u_a*( - G_int_a);
    k2_xiMean_2 = v_a*( - G_int_a);
    
    xiMean_1_a = interp2_periodic(xx,yy,xiMean_1_d,X_d,Y_d,interp_methodx) ...
        + dt/2*(k1_xiMean_1 + k2_xiMean_1);
    xiMean_2_a = interp2_periodic(xx,yy,xiMean_2_d,X_d,Y_d,interp_methodx) ...
        + dt/2*(k1_xiMean_2 + k2_xiMean_2);
    
    % write this updated xiMean to the output variable
    xiMean_a = cat(3,xiMean_1_a,xiMean_2_a);


    % then update uvLM_phi -----------------------------------------
    k1_uvLM_phi_1 = interp2_periodic(xx,yy,u_d,X_d,Y_d,interp_methodx)*G_d;
    k1_uvLM_phi_2 = interp2_periodic(xx,yy,v_d,X_d,Y_d,interp_methodx)*G_d;

    k2_uvLM_phi_1 = u_a*G_a;
    k2_uvLM_phi_2 = v_a*G_a;

    uvLM_phi_1_a = interp2_periodic(xx,yy,uvLM_phi_d(:,:,1),X_d,Y_d,interp_methodx) ...
        + dt/2*(k1_uvLM_phi_1 + k2_uvLM_phi_1);

    uvLM_phi_2_a = interp2_periodic(xx,yy,uvLM_phi_d(:,:,2),X_d,Y_d,interp_methodx) ...
        + dt/2*(k1_uvLM_phi_2 + k2_uvLM_phi_2);

    % write this updated xiMean to the output variable
    uvLM_phi_a = cat(3,uvLM_phi_1_a,uvLM_phi_2_a);

end