function f_remap = remap2_periodic(x_sample,y_sample,f,x,y)

x_sample_right = x_sample(x_sample>15/16*2*pi);
y_sample_right = y_sample(x_sample>15/16*2*pi);
f_right = f(x_sample>15/16*2*pi);

x_sample_left = x_sample(x_sample<1/16*2*pi);
y_sample_left = y_sample(x_sample<1/16*2*pi);
f_left = f(x_sample<1/16*2*pi);

x_sample_up = x_sample(y_sample>15/16*2*pi);
y_sample_up = y_sample(y_sample>15/16*2*pi);
f_up = f(y_sample>15/16*2*pi);

x_sample_down = x_sample(y_sample<1/16*2*pi);
y_sample_down = y_sample(y_sample<1/16*2*pi);
f_down = f(y_sample<1/16*2*pi);

x_instant = cat(1,x_sample,x_sample_down,x_sample_down+2*pi,...
    x_sample_left+2*pi,x_sample_left+2*pi,...
    x_sample_up,x_sample_up-2*pi,...
    x_sample_right-2*pi,x_sample_right-2*pi);
y_instant = cat(1,y_sample,y_sample_down+2*pi,y_sample_down+2*pi,...
    y_sample_left,y_sample_left-2*pi,...
    y_sample_up-2*pi,y_sample_up-2*pi,...
    y_sample_right,y_sample_right+2*pi);

f_instant = cat(1,f,f_down,f_down,f_left,f_left,f_up,f_up,f_right,f_right);

f_remap = griddata(x_instant,y_instant,f_instant,x,y,'cubic');

% F = scatteredInterpolant(x_instant,y_instant,f_instant);
% % F = scatteredInterpolant(x_sample,y_sample,f);
% 
% f_remap = F(x,y);

