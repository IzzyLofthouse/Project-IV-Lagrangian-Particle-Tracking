%---load data---
load('uLM_averaging_sinc.mat')  %or _th
addpath('/MATLAB Drive/SW_share/SW_share/.')
load('/MATLAB Drive/SW_share/SW_share/Lagrangian_mean_field_50.mat','time','x_pstns_sinc','y_pstns_sinc','u_L_at_t_sinc','v_L_at_t_sinc') %or _th
load('/MATLAB Drive/SW_share/SW_share/tracer_diagnostics_test_1000.mat','Ntracers')
load('/MATLAB Drive/SW_share/SW_share/IC_MO.mat','xx','yy')
%pick time (1 unless fields were filtered at more than 1 time)
k=1;

%------rename------
uLM_sinc = uLM_save_sinc;
vLM_sinc = vLM_save_sinc;

%------pre-allocate------
uLM_av_traj_pts_sinc = zeros(Ntracers,1);
vLM_av_traj_pts_sinc = zeros(Ntracers,1);

%------wrap positions------
eps_safe = 1e-12;
pstns_x_sinc = mod(x_pstns_sinc, 2*pi);
pstns_y_sinc = mod(y_pstns_sinc, 2*pi);
pstns_x_sinc(pstns_x_sinc >= 2*pi - eps_safe) = 0;
pstns_y_sinc(pstns_y_sinc >= 2*pi - eps_safe) = 0;
%------Interpolate actual Lagrangian velocity onto average tracer positions------
 for i = 1:Ntracers
    uLM_av_traj_pts_sinc(i) = interp2_periodic(xx, yy, uLM_sinc, pstns_x_sinc(i,k), pstns_y_sinc(i,k), 'linear');                        
    vLM_av_traj_pts_sinc(i) = interp2_periodic(xx, yy, vLM_sinc, pstns_x_sinc(i,k), pstns_y_sinc(i,k), 'linear');
 end

%------find absolute error between actual Lagrangian velocity and
% Lagrangian velocity of tracer
 err_u_sinc = u_L_at_t_sinc - uLM_av_traj_pts_sinc;
 err_v_sinc = v_L_at_t_sinc - vLM_av_traj_pts_sinc;
 abs_err_u_sinc = abs(err_u_sinc);
 abs_err_v_sinc = abs(err_v_sinc);


% Calculate the mean and standard deviation of the errors - sinc
mean_err_u_sinc = mean(abs_err_u_sinc);
mean_err_v_sinc = mean(abs_err_v_sinc);
std_err_u_sinc = std(abs_err_u_sinc);
std_err_v_sinc = std(abs_err_v_sinc);

%calculate absolute and relative errors
abs_err_sinc = sqrt(abs_err_u_sinc.^2 + abs_err_v_sinc.^2);
rel_err_sinc = abs_err_sinc ./norm(sqrt(uLM_av_traj_pts_sinc.^2+vLM_av_traj_pts_sinc.^2));

disp(['absolute mean error u sinc=', num2str(mean_err_u_sinc)]);
disp(['absolute mean error v sinc=', num2str(mean_err_v_sinc)]);
disp(['Standard deviation of absolute errors of u sinc=', num2str(std_err_u_sinc)]);
disp(['Standard deviation of  absolute errors of v sinc=', num2str(std_err_v_sinc)]);

%calculate NRMS and correlations (Pearson correlation)
rms_err_u_sinc = sqrt(mean(err_u_sinc.^2));
rms_err_v_sinc = sqrt(mean(err_v_sinc.^2));
nrms_u_sinc = rms_err_u_sinc / (max(uLM_av_traj_pts_sinc)-min(uLM_av_traj_pts_sinc));
nrms_v_sinc = rms_err_v_sinc / (max(vLM_av_traj_pts_sinc)-min(vLM_av_traj_pts_sinc));  
corr_u_sinc = corr(u_L_at_t_sinc(:), uLM_av_traj_pts_sinc(:));
corr_v_sinc = corr(v_L_at_t_sinc(:), vLM_av_traj_pts_sinc(:));


%------plot bar chart of absolute error and 'relative error'------
figure
bar(1:Ntracers, rel_err_sinc);
title('Relative error using a sinc kernel','FontSize',20)
xlabel('tracer number','FontSize',20) %'scaled absolute error'
grid on;

figure
bar(1:Ntracers,abs_err_sinc);
title('Absolute error using a sinc kernel','FontSize',20)
xlabel('tracer number','FontSize',20)
grid on;



vec_err = sqrt((u_L_at_t_sinc - uLM_av_traj_pts_sinc).^2 + ...
               (v_L_at_t_sinc - vLM_av_traj_pts_sinc).^2);

vel_mag = sqrt(uLM_av_traj_pts_sinc.^2 + vLM_av_traj_pts_sinc.^2);
nrms_local = vec_err ./ (vel_mag + 1e-12);

figure
bar(sort(nrms_local))
title('Local normalized velocity error')



disp(['Position x: ', num2str(pstns_x_sinc(14,k))])
disp(['Position y: ', num2str(pstns_y_sinc(14,k))])

figure
imagesc(xx, yy, uLM_sinc)
shading flat; colorbar; clim([-0.1 0.1]);
hold on
% Mark the outlier tracers
[~, outlier_idx] = sort(abs_err_sinc, 'descend');
top_outliers = outlier_idx(1:50);
scatter(pstns_x_sinc(top_outliers,k), pstns_y_sinc(top_outliers,k), ...
    25, 'r', 'filled')
title('Lagrangian u sinc field with top 50 outlier tracers marked')

figure
imagesc(xx, yy, vLM_sinc)
shading flat; colorbar; clim([-0.1 0.1]);
hold on
% Mark the outlier tracers
[~, outlier_idx] = sort(abs_err_sinc, 'descend');
top_outliers = outlier_idx(1:50);
scatter(pstns_x_sinc(top_outliers,k), pstns_y_sinc(top_outliers,k), ...
    25, 'r', 'filled')
title('Lagrangian v sinc field with top 50 outlier tracers marked')

