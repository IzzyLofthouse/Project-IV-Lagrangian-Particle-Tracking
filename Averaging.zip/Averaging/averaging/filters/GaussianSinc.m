function s = GaussianSinc(t,omega_c,sigma)
% Gaussian multiplied by sinc function
% sigma is standard deviation in spectral space

s = exp(-sigma^2*t.^2/2) .* sin(omega_c*t)./(pi*t);
s(t==0) = omega_c/pi;

s = s/erf(omega_c/(sigma*sqrt(2)));