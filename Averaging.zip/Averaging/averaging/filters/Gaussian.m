function s = Gaussian(t,T,theta)

% normalised Gaussian function

s = exp(-t.^2/(2*theta^2)) / (sqrt(2*pi)*theta*erf(T/(2*sqrt(2)*theta)));