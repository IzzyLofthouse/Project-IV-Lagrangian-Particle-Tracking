function s = tophat(t,T)

% tophat function

s = zeros(size(t));
s(t >= -T/2 & t <= T/2) = 1/T;