syms x %makes x a symbolic variable
f= piecewise(-2<x & x<-1, 0, x>=-1 & x<1, 1/2, x>=1 & x<2, 0);
%makes a piecewise function for given conditions
figure;
fplot(f,'LineWidth', 1); hold on;
plot(-1:0.001:1,.55,'r'); grid on;
set(gca, 'XTickLabel', [], 'YTickLabel', [])

