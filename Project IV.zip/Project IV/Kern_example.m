dt = 1e-3;
x = -30:dt:30;   % extend from ±10 to ±50
N = length(x);

omega = 1;

omega_c = 1;
f = sin(x)+1/2*cos(10*x);
f_th = 0.492*sin(x);
f_s = sin(x);
f_G = 0.95*sin(x)+0.005*cos(10*x);
f_GS = 0.97*sin(x) + 0.005*cos(10*x);
figure
mycolors = [0.5 0.3 1; 0.2 1 0.2; 1 0 0; 0 0.8 1; 1 0.6 0];
ax = gca;
ax.ColorOrder = mycolors;
hold on;

plot(x, f, 'LineWidth', 1.5);
plot(x,f_th,'LineWidth',1.5);
plot(x,f_s,'LineWidth',1.5);
plot(x,f_G,'LineWidth',1.5);
plot(x,f_GS,'LineWidth',1.5);
legend('original function', 'top-hat kernel','sinc kernel','Gaussian kernel','Gaussian-sinc kernel','FontSize',13)

xlim([-10, 10])
ylim([-1.6,1.6])
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';

grid on
hold off;