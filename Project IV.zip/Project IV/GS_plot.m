
dt = 1e-3;
x = -30:dt:30;   % extend from ±10 to ±50
N = length(x);


omega = 1;

omega_c = 1;
figure
mycolors = [0.5 0 1; 0 1 0; 1 0 0; 0 0.8 1];
ax = gca;
ax.ColorOrder = mycolors;
hold on;

for sigma = [0.1, 0.25, 0.5, 1]
    result = GS_freq(x, omega, sigma);
 
    plot(x, result, 'LineWidth', 1.6);
end

legend('\sigma = 0.1','\sigma = 0.25','\sigma = 0.5','\sigma = 1', 'FontSize', 20)
xlim([-4, 4])
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
grid on
hold off;


function r = GS_freq(x, omega_c, sigma)
    kern = GaussianSinc(x, omega_c, sigma);
    area = trapz(x, kern);   % numerical integral of the kernel over your grid
    r = (pi / area) * (erf((x + omega_c) ./ (sqrt(2)*sigma)) ...
                     - erf((x - omega_c) ./ (sqrt(2)*sigma)));
end