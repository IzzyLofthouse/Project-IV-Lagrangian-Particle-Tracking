dt = 1e-3;
x = -30:dt:30;   % extend from ±10 to ±50
N = length(x);

omega = 1;

omega_c = 1;
figure
mycolors = [0.5 0 1; 0 1 0; 1 0 0; 0 0.8 1];
ax = gca;
ax.ColorOrder = mycolors;
hold on;

result = erf(x); 
plot(x, result, 'LineWidth', 1.6);


%legend('\sigma = 0.1','\sigma = 0.25','\sigma = 0.5','\sigma = 1', 'FontSize', 20)
xlim([-4, 4])
ylim([-1.6,1.6])
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
grid on
hold off;

