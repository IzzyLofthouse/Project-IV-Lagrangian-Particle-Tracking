dt = 1e-3;
x = -10:dt:10;
hat_width = 9;

figure
mycolors = [0.5 0 1; 0 1 0; 1 0 0; 0 0.8 1];
ax = gca;
ax.ColorOrder = mycolors;
hold on;

for cutoff = [0.5, 1, 2, 3]
    result = sinc_tophat_conv(x, cutoff, hat_width);
    plot(x, result, 'LineWidth', 1.6);
end
legend('cut-off = 0.75','cut-off = 1','cut-off = 2','cut-off = 3', 'FontSize', 20)
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
ax.XTick = [];
ax.YTick = [];
grid on
hold off;


function result = sinc_tophat_conv(x, cutoff, hat_width)
    % Convolution of sinc and top-hat function in real space
    % Inputs:
    %   x         - input vector
    %   cutoff    - cutoff frequency of the sinc
    %   hat_width - full width of the top-hat function
    
    dt = x(2) - x(1);
    
    % Define sinc
    s = cutoff/pi * sinc(cutoff * x);
    
    % Define top-hat (centred at 0, width = hat_width)
    hat = double(abs(x) <= hat_width/2);
    
    % Convolve and scale by dt
    result = conv(s, hat, 'same') * dt;
end