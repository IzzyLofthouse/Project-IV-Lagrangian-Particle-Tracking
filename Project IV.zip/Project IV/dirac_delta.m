function y = my_dirac(x, pos, width)
    y = exp(-(x-pos).^2/(2*width^2))/(width*sqrt(2*pi));
end

% Usage:
width = 0.01;  % Adjust this value to control the width
dt = 1e-3;
x= -3:dt:3;
y = my_dirac(x, 0.5, width) - my_dirac(x, -0.5, width) + my_dirac(x, 2.5, width) + my_dirac(x, -2.5, width);
figure
ax = gca;

plot(x,y,'LineWidth',1,'color','b'); hold on;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
box off;
ax.LineWidth = 1;
ax.YTick = [];
ax.XTick = [];

syms x %makes x a symbolic variable
f= piecewise(-3<x & x<-1.5, 0, x>=-1.5 & x<1.5, 25, x>=1.5 & x<3, 0);
%makes a piecewise function for given conditions
fplot(f,'LineWidth', 1,'color','r'); hold on;
plot(-1:0.001:1,.55,'r','LineWidth',1); 

text(-1.5,0,'-ω_c', 'HorizontalAlignment','center','VerticalAlignment','top','FontSize',12);
text(1.5,0,'ω_c', 'HorizontalAlignment','center','VerticalAlignment','top','FontSize',12);
text(-2.5, 0, '-10', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', 'FontSize', 12);
text(-0.5, 0, '-1', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', 'FontSize', 12);
text(0.5, 0, '1', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', 'FontSize', 12);
text(2.5, 0, '10', 'HorizontalAlignment', 'center', 'VerticalAlignment', 'top', 'FontSize', 12);
hold off;
