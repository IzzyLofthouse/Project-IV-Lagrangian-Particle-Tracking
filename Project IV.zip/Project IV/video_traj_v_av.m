clear
close all

% ----- TIME -----
T  = 20;
Nt = 1500;
t  = linspace(0,T,Nt);

% ----- PARAMETERS -----
omega  = 4;      % fast oscillation
R_big  = 5;       % radius of mean path
r      = 1;     % small oscillation size
U     = 0.4;     % drift speed

alpha = 0.5;   % mean travels at 50% speed
tau = alpha*t;

% ----- MEAN TRAJECTORY (slow clockwise curve) -----

x_mean = tau;
y_mean = 3*log(100*tau)-5;


% ----- RAW TRAJECTORY (mean + oscillation) -----
x_raw = x_mean + 1/2*r*cos(omega*t);
y_raw = y_mean + r*sin(omega*t);

% ----- VIDEO SETUP -----
v = VideoWriter('GLM_clean_demo.avi','Motion JPEG AVI');
v.FrameRate = 30;
v.Quality   = 100;   % maximum quality
open(v);


set(gca,'LineWidth',1.5)

figure;
%set(gcf,'Position',[100 100 1920 1080])
set(gcf,'Renderer','opengl')
axis equal
axis([-5,20,1,20])
box off
set(gca,'xtick',[],'ytick',[])
hold on

for k = 20:Nt
    
    cla
    
    % Trails
    plot(x_raw(20:k),  y_raw(20:k),  'r','LineWidth',2);
    plot(x_mean(20:k), y_mean(20:k), 'b','LineWidth',3);
    
    % Heads
    plot(x_raw(k),  y_raw(k),'ro','MarkerFaceColor','r');
    plot(x_mean(k), y_mean(k),'bo','MarkerFaceColor','b');
    
    drawnow
    frame = getframe(gcf);
    writeVideo(v,frame);
end

close(v);